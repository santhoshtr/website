import gedit
import gtk
from approximatesearchinstance import ApproximateSearchInstance

class RegexSearch(gedit.Plugin):
    DATA_TAG = "ApproximateSearchInstance"

    def __init__(self):
        gedit.Plugin.__init__(self)

    def activate(self, window):
        approximatesearch_instance = ApproximateSearchInstance(window)
        window.set_data(self.DATA_TAG, approximatesearch_instance)
	
    def deactivate(self, window):
        regexsearch_instance = window.get_data(self.DATA_TAG)
        # advancedsearch_instance destroy!?
        window.set_data(self.DATA_TAG, None)
		
    def update_ui(self, window):
        approximatesearch_instance = window.get_data(self.DATA_TAG)
        approximatesearch_instance.update_ui()

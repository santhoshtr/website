import gedit
from gettext import gettext as _
import gtk
import gtk.glade
import os
import re
import soundex
import inexactsearch
ui_str = """
<ui>
    <menubar name="MenuBar">
        <menu name="SearchMenu" action="Search">
            <placeholder name="SearchOps_3">
                <menuitem name="Approximate Search" action="ApproximateSearch"/>
            </placeholder>
        </menu>
    </menubar>
</ui>
"""

GLADE_FILE = os.path.join(os.path.dirname(__file__), "approximatesearch.glade")

class ApproximateSearchInstance:

	###
	# Object initialization
	def __init__(self, window):
		self._window = window
		self.create_menu_item()
		self.load_dialog()


	###
	# Create menu item 
	# Create our menu item in "Search" menu.
	def create_menu_item(self):
		action = gtk.Action("ApproximateSearch", _("Approximate Search"), _("Search using regular expressions, soundslike, similar"), None)
		action.connect("activate", self.on_open_regex_dialog)
		action_group = gtk.ActionGroup("ApproximateSearchActions")
		action_group.add_action(action)
		manager = self._window.get_ui_manager()
		manager.insert_action_group(action_group, -1)
		manager.add_ui_from_string(ui_str)


	###
	# Load dialog.
	#   - Load dialog from its Glade file
	#   - Connect widget signals
	#   - Put needed widgets in object variables. 
	def load_dialog(self):
		glade_xml = gtk.glade.XML(GLADE_FILE)

		self._search_dialog = glade_xml.get_widget("search_dialog")
		self._search_dialog.hide()
		self._search_dialog.set_transient_for(self._window)
		self._search_dialog.set_destroy_with_parent(True)
		self._search_dialog.connect("delete_event", self._search_dialog.hide_on_delete)

		self._find_button = glade_xml.get_widget("find_button")
		self._find_button.connect("clicked", self.on_find_button_clicked)

		close_button = glade_xml.get_widget("close_button")
		close_button.connect("clicked", self.on_close_button_clicked)

		self._search_text_box = glade_xml.get_widget("search_text")
		self._search_text_box.connect("changed", self.on_search_text_changed)

		self._wrap_around_check = glade_xml.get_widget("wrap_around_check")
		self._similar_check = glade_xml.get_widget("similar_check")
		self._sounds_like_check = glade_xml.get_widget("sounds_like_check")
		self._case_sensitive_check = glade_xml.get_widget("case_sensitive_check")


	###
	# Called when the "Find" button is clicked.
	def on_find_button_clicked(self, find_button):
		self.search_document()


	###
	# Called when the "Close" button is clicked.
	def on_close_button_clicked(self, close_button):
		self._search_dialog.hide()


	###
	# Called when the text to be searched is changed.
	def on_search_text_changed(self, search_text_entry):
		search_text = search_text_entry.get_text()

		if len(search_text) > 0:
			self._find_button.set_sensitive(True)
		else:
			self._find_button.set_sensitive(False)


	###
	# To update plugin's user interface
	def update_ui(self):
		pass


	###
	# Called to open the Regex Search dialog.
	def on_open_regex_dialog (self, action = None):
		self._search_dialog.show()


	###
	# Search the document.
	#
	# The search begins from the current cursor position.
	def search_document(self, start_iter = None, wrapped_around = False):
		document = self._window.get_active_document()

		if start_iter == None:
			#Get cursor location
			start_iter = document.get_iter_at_mark(document.get_insert())
		#Get document end location
		end_iter = document.get_end_iter()
		#Get the key and text
		text = unicode(document.get_text(start_iter, end_iter, False), "utf-8")
		search_key = unicode(self._search_text_box.get_text(), "utf-8")
		
		start = -1
		#do exact search first
		if self._case_sensitive_check.get_active() :
			start = text.find(search_key)
		else :
			start = (text.lower()).find(search_key.lower())
		if 	start <  0 :
			#do sounds like search	'''
			if 	self._sounds_like_check.get_active() :
				sx= soundex.Soundex()
				start = sx.find(text,search_key)
			#do inexact search			'''
			if 	start == -1 and self._similar_check.get_active() :
				isearch= inexactsearch.ApproximateSearch()
				start = isearch.find(text,search_key)	
				
		if start >= 0:
			# There is a match
			end = start  + len(search_key)
			self.handle_search_result(start,end, document, start_iter, wrapped_around)
		else:
			# No match found

			if self._wrap_around_check.get_active() and not wrapped_around and start_iter.get_offset() > 0:
				# Let's wrap around, searching the whole document
				self.search_document(document.get_start_iter(), True)
			else:
				# We've already wrapped around. There's no match in the whole document.
				self.inform_no_match()


	###
	# Inform no match
	# Inform the user that no match has been found for the specified regular expression.
	def inform_no_match(self):
		dlg = gtk.MessageDialog(self._window,
								gtk.DIALOG_MODAL | gtk.DIALOG_DESTROY_WITH_PARENT,
								gtk.MESSAGE_INFO,
								gtk.BUTTONS_CLOSE,
								_(u"Could not fine  \"%s\" ." % self._search_text_box.get_text()))
		dlg.run()
		dlg.hide()


	###
	# Handle search's result.
	# If the result is already selected, we search for the next match.
	# Otherwise we show it.
	#
	# The parameter "result" should contain the match result of a regex search.
	def handle_search_result(self, start, end, document, start_iter, wrapped_around = False):
		curr_iter = document.get_iter_at_mark(document.get_insert())
		selection_bound_mark = document.get_mark("selection_bound")
		selection_bound_iter = document.get_iter_at_mark(selection_bound_mark)

		# If our result is already selected, we will search again starting from the end of
		# of the current result.
		if start_iter.get_offset() + start  == curr_iter.get_offset() and \
		   start_iter.get_offset() + end  == selection_bound_iter.get_offset():

			start_iter.forward_chars(end+1) # To the first char after the current selection/match.

			if start_iter.get_offset() < document.get_end_iter().get_offset() and not wrapped_around:
				self.search_document(start_iter)
		else:
			self.show_search_result(start, end , document, start_iter)

	###
	# Show search's result.
	# i.e.: Select the search result text, scroll to that position, etc.
	#
	# The parameter "result" should contain the match result of a regex search.
	def show_search_result(self, start, end, document, start_iter):
		selection_bound_mark = document.get_mark("selection_bound")

		result_start_iter = document.get_iter_at_offset(start_iter.get_offset() + start)
		result_end_iter = document.get_iter_at_offset(start_iter.get_offset() +  end)

		document.place_cursor(result_start_iter)
		document.move_mark(selection_bound_mark, result_end_iter)

		view = self._window.get_active_view()
		view.scroll_to_cursor()

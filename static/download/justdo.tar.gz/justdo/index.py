#!/home/thottingal/bin/python
# -*- coding: utf-8 -*-
import traceback
import cgitb
import cgi
from TODO import Todo

cgitb.enable(True, "logs/")
def index(form):
	response=open("index.html").read()
	todo=Todo()
	action=None
	if(form.has_key('show')):
		show = form['show'].value.decode("utf-8")
	else:
		show = "finished"

	if(form.has_key('action')):
		action=form['action'].value	
	else:
		response=response.replace("$$INFO$$","")
	if action=="Add":
		if(form.has_key('task')):
			task = form['task'].value.decode("utf-8")
		if(form.has_key('desc')):
			desc = form['desc'].value.decode("utf-8")
		else:
			desc= "" 
		if(form.has_key('date')):
			date = form['date'].value.decode("utf-8")
		else:
			date = ""
			
		todo.add(task, desc,date)
		response=response.replace("$$INFO$$","<b>Task Added!!!<b></br>")
	if action=="Done":
		id = form['id'].value
		todo.done(id)
		response=response.replace("$$INFO$$","<b>Task Marked as Done!!!<b></br>")
	if action=="Delete":
		try:
			id = form['id'].value
			todo.delete(id)
		except:
			response=response.replace("$$INFO$$","<b>Failed<b></br>")
		response=response.replace("$$INFO$$","<b>Task Deleted Successfully<b></br>")
	todo.save()
	tasks  =	todo.list(False)
	tasktable = "<table border='0' width='100%'><tr><th>No</th><th>Task</th><th>Desc</th><th>Submitted on</th><th>Due Date</th><th>Status</th><th>Delete</th></tr>"
	count = 1
	for task in tasks :
		if show == "finished":
			if task.done:
				continue
		tasktable += "<tr><td>"+ str(count) + "</td><td>" +  task.task + "</td><td>" + task.desc+ "</td>"
		try:
			tasktable += "<td>" + task.subdate+ "</td>"
		except:
			tasktable += "<td></td>"	
		tasktable += "<td>" + task.date  
		if task.done :
			tasktable += "</td><td>Done</td>"
		else:
			tasktable += "<td><a href='?action=Done&id="+str(task.id)+"'>Done</a></td>"
		tasktable += "<td><a href='?action=Delete&id="+str(task.id)+"'>Delete</a></td></tr>"
		count +=1
	tasktable += "</table>"
	response=response.replace("$$TASKTABLE$$",tasktable)
	return response	
if __name__ == '__main__':
	print "Content-Type: text/html\n\n"
	print index(cgi.FieldStorage()).encode('utf-8')

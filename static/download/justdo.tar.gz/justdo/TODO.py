import os, sys
import uuid
import pickle
import datetime
from task import Task
class Todo:
	def __init__(self):
		self.tasks=[]
		try:
			pkl_file = open("todo.db", 'rb')
			self.tasks=pickle.load(pkl_file)
		except:
			pass
		
	def add(self,task, desc=None,date=None):
		newtask=Task()
		newtask.id  =str(uuid.uuid1())
		newtask.task= task
		newtask.desc = desc
		newtask.date = date
		newtask.subdate = str(datetime.date.today())
		self.tasks.append(newtask)
	def done(self,id):
		for item in self.tasks:
			if item.id == id:
				item.done=True
		
	def delete(self,id):
		for item in self.tasks:
			if item.id == id:
				self.tasks.remove(item)
        	
	def get(self,id):
		for item in self.tasks:
			if item.id == id:
        			return item
        	return None		
	def save(self):
		output = open('todo.db', 'wb')
		pickle.dump(self.tasks,output)
		output.close()
		#Refresh the list
		pkl_file = open("todo.db", 'rb')
		self.tasks=pickle.load(pkl_file)
		
	def list(self, finished=True):
		returnList = list()
		for item in self.tasks:
			if finished :
				if not item.done:
					returnList.append( item)	
        		else:
				returnList.append( item)
		return returnList



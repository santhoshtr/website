import os, sys
class Task:
	def __init__(self):
		self.id=None
		self.task=None
		self.desc=None
		self.date=None
		self.subdate=None
		self.done=False
	def __str__(self):
		return str(self.id) + " : " + self.task + " : " + self.desc + " : " + self.date + " : " + str(self.done)
		
		
	
